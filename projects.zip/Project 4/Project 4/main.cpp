//
//  main.cpp
//  Project 4
//
//  Created by Nilay Modi on 11/10/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int appendToAll(string a[], int n, string value)
{
    if(n >= 0){
        for(int i = 0; i<n; i++){
            a[i] = a[i]+value; // appends value to string
        }
        return n;
    }else return -1;
}

int lookup(const string a[], int n, string target)
{
    if(n >= 0){
        for (int i = 0; i<n; i++) {
            if(a[i] == target) return i; // return index if target found
        }
        return -1; // if target is not found
    }else return -1;
}

int positionOfMax(const string a[], int n)
{
    int count = 0; //refers to matches made
    if(n > 0){
        for(int i = 0; i<n; i++){
                string firstOne = a[i];
            for (int j = 0; j<n; j++) {
                string secondOne = a[j];
                if(firstOne >= secondOne){
                    count++;
                }else break;
            }
            
            // checking if matches made is equal to no. of elements in array
            if (count == n) {
                return i;
            }
            
            count = 0;
        }
        return -1; // should never execute
    }else return -1;
}

int rotateLeft(string a[], int n, int pos)
{
    //position moved has to be less than elements in array
    if(n >= 0 && pos<n && pos >= 0){
        string temp;
        for(int i = pos; i<n-1; i++){
            
            // switching elements with the next
            temp = a[i];
            a[i] = a[i+1];
            a[i+1] = temp;
        }
        return pos;
    }else return -1;
}

int rotateRight(string a[], int n, int pos)
{
    //position moved has to be less than elements in array
    if(n >= 0 && pos<n && pos >= 0){
        string temp;
        
        // loop going backwards
        for(int i = pos; i>0; i--){
            
            // switching elements with the previous
            temp = a[i];
            a[i] = a[i-1];
            a[i-1] = temp;
        }
        return pos;
    }else return -1;
}

int flip(string a[], int n)
{
    if(n >= 0){
        string temp;
        
        for(int i = 0; i<n; i++){
            if(i == n/2) break; // if midpoint reached, stop looping
            
            // switch current element with (last element - current element)
            temp = a[i];
            a[i] = a[n-1-i];
            a[n-1-i] = temp;
        }
        
        return n;
    }else return -1;
}

int differ(const string a1[], int n1, const string a2[], int n2)
{
    if(n1 >= 0 && n2 >= 0){
        int i = 0;
        
        // keep looping until end of one of the arrays is reached
        while(i != n1 && i != n2){
            if(a1[i] == a2[i]) i++;
            else break; // break if element is not equal
        }
        
        // returns the position of the first coresponding elements that are not equal
        return i;
    }else return -1;
}

int subsequence(const string a1[], int n1, const string a2[], int n2)
{
    // array being searched for must be smaller than the array looked within
    if(n1 >= 0 && n2 >= 0 && n2 <= n1){
        if(n2 == 0) return 0; // if nothing is being searched
        else{
            for(int i = 0; i<=n1-n2; i++){
                int count;
                if(a1[i] == a2[0]){ // look until first element matches
                    count = 0;
                    for(int j = 0; j != n2; j++){
                        
                        // increase count for every subsequent match
                        if(a1[i+j] == a2[j]) count++;
                        else break;
                    }
                }
                
                // returns that start pos of the subsequence
                if(count == n2) return i;
            }
        }
        return -1; // if subsequence not found
    }else return -1;
}

int lookupAny(const string a1[], int n1, const string a2[], int n2)
{
    if(n1 >= 0 && n2 >= 0){
        for(int i = 0; i<n1; i++){
            for (int j = 0; j<n2; j++) {
                //if matches then return pos in first array
                if(a1[i] == a2[j]) return i;
            }
        }
        return -1; // return -1 when nothing matches
    }else return -1;
}

int separate(string a[], int n, string separator)
{
    if(n >= 0){
        // quadratic to n
        for(int count = 0; count < n; count++){
            for(int i = 0; i < n-1; i++){
                if(a[i] > a[i+1]){
                    //if greater than seperator, switch with next element
                    string temp = a[i];
                    a[i] = a[i+1];
                    a[i+1] = temp;
                }
            }
        }
        
        // loop through and return pos of value not less than separator
        for(int k = 0; k<n; k++){
            if(!(a[k] < separator)) return k;
        }
        
        // returns n if there are no such values greater than separator
        return n;
    }else return -1;
}

int main() {
    
    //int val = 0;
    //string items [5] = {"apple", "banana", "carrot", "octopus"};
    //string cast[6] = { "glenn", "carl", "carol", "rick", "RICK", "daryl" };
    //string items1[7] = {"a", "b", "c", "a", "b", "c", "d"};
    //string items2[4] = {"a", "b", "c", "d"};
    //string cast[6] = { "maggie", "carl", "daryl", "rick", "michonne", "carol" };
    //string cast2[5] = {"apple", "tea", "elephant", "woot", "bae"};
    
    //val = appendToAll(items, n, "!!!");
    //val = lookup(items, 0, "apple");
    //val = positionOfMax(cast, 0);
    //val = rotateLeft(items, n, 0);
    //val = rotateRight(c, 3, 1);
    //val = flip(items, 3);
    //val = differ(roles, 2, group, 3);
    //val = subsequence(items1, 7, items2, 4);
    //val = lookupAny(names, 6, set2, 2);
    //val = separate(cast, 6, "glen");
    //val = separate(cast2, 4, "zebra");
    
    //cout << val << endl;
    
    /*
    for(int i = 0; i<5; i++){
        cout << cast2[i] << endl;
    }
    */
    
    string items[5] = {"zebra", "horse", "camel", "monkey"};
    rotateRight(items, 4, 1);
    
    for(int i = 0; i<5; i++){
        cout << items[i] << endl;
    }
}

