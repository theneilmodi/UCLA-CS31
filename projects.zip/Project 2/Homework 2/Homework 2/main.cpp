//
//  main.cpp
//  Homework 2
//
//  Created by Nilay Modi on 10/16/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int week = 10;
    
    switch (week) {
        case 0:
            cout << "first lecture";
            break;
        case 4:
            cout << "midterm";
            break;
        case 8:
            cout << "midterm";
            break;
        case 10:
            cout << "final";
            break;
        default:
            cout << "nothing";
    }
}