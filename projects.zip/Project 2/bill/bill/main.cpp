//
//  main.cpp
//  bill
//
//  Created by Nilay Modi on 10/16/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    
    //user input for minutes
    cout << "Minutes used: ";
    int minutes;
    cin >> minutes;
    
    if(minutes < 0){
        cout << "---" << endl;
        cout << "The number of minutes used must be nonnegative.";
        return 0;
    }
    
    //user input for text messages
    cout << "Text messages: ";
    int messages;
    cin >> messages;
    cin.ignore(10000, '\n');
    
    if(messages < 0){
        cout << "---" << endl;
        cout << "The number of text messages must be nonnegative.";
        return 0;
    }

    //user input for customer name
    cout << "Customer name: ";
    string name;
    getline(cin, name);
    
    if(name == ""){
        cout << "---" << endl;
        cout << "You must enter a customer name.";
        return 0;
    }
    
    //user input for month
    cout << "Month number (1=Jan, 2=Feb, etc.): ";
    int month;
    cin >> month;
    
    if(month > 12 || month < 1){
        cout << "---" << endl;
        cout << "The month number must be in the range 1 through 12.";
        return 0;
    }
    
    //base bill
    double bill = 40;
    
    // with minutes
    if(minutes > 500) bill = bill + (minutes-500) * 0.45;
    
    //with messages greater than 200
    if(messages > 200){
        int tempMessages;
        if(messages > 400) tempMessages = 200;
        else tempMessages = messages-200;
        
        //october to may
        if(month <= 5 || month >= 10) bill = bill + (tempMessages * 0.03);
        else bill = bill + (tempMessages * 0.02); //summer
    }
    
    // when greater than 400
    if(messages > 400){
        int tempMessages = messages-400;
        bill = bill + (tempMessages * 0.11);
    }

    cout << "---" << endl;
    
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    
    cout << "The bill for " << name << " is $" << bill << endl;
    
}
