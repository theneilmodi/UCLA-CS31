//
//  main.cpp
//  Project 5
//
//  Created by Nilay Modi on 11/27/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#include <iostream>
using namespace std;

void removeS(char *msg){
    char* ptr;
    while (*msg != 0) {
        
        if(*msg == 'S' || *msg == 's'){
            ptr = msg;
            while(*msg != 0){
               *msg = *(msg+1);
                msg++;
            }
            msg = ptr;
        }else{
           msg++;
        }
    }
}

int main()
{
    char msg[50] = "She'll be a massless princess.";
    removeS(msg);
    cout << msg;  // prints   he'll be a male prince.
}
